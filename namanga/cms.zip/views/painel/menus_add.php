<h1>Adicionar Menu</h1>
<form method="POST">
	Nome do Menu:<br/>
	<input type="text" name="nome" /><br/><br/>

	URL do Menu:<br/>
	<input type="text" name="url" /><br/><br/>

	<input type="submit" value="Salvar" />
</form>