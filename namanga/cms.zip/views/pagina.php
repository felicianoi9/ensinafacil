<h1><?php echo utf8_encode($titulo); ?></h1>
<?php echo utf8_encode($corpo); ?>